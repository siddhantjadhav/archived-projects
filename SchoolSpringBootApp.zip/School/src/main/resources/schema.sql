create table student(
id integer not null,
name varchar(50) not null,
subjects varchar(255)
);

create table subject(
id integer not null,
name varchar(50) not null,
teacher integer not null
);

create table teacher(
id integer not null,
name varchar(50) not null,
subject integer not null
);
