INSERT INTO student (id, name, subjects) VALUES
(1, 'John', null);
INSERT INTO student (id, name, subjects) VALUES
(2, 'Adam', null);
INSERT INTO student (id, name, subjects) VALUES
(3, 'Liam', null);
INSERT INTO student (id, name, subjects) VALUES
(4, 'Peter', null);

INSERT INTO subject VALUES
(1, 'Maths', 1),
(2, 'Chemistry', 2),
(3, 'English', 3),
(4, 'Physics', 4);

INSERT INTO teacher VALUES
(1, 'Dubey', 1),
(2, 'Patil', 2),
(3, 'Sen', 3),
(4, 'Dave', 4);