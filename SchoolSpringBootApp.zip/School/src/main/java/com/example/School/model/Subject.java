package com.example.School.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Subject {

	@Id
	private int subjectId;
	private String name;
	
	@ManyToMany(mappedBy="subjects")
	private List<Student> students = new ArrayList<>();
	
	@OneToOne
	private Teacher teacher;
	
	
	
}
