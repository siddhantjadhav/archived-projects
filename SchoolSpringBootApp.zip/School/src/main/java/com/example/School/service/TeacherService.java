package com.example.School.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.School.dao.TeacherRepository;
import com.example.School.model.Teacher;

@Service
public class TeacherService {

	@Autowired
	TeacherRepository teacherRepository;
	
	public List<Teacher> getAllStudents(){
		return teacherRepository.findAll();
	}
}
