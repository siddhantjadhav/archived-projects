package com.example.School.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.School.dao.SubjectRepository;
import com.example.School.model.Subject;

@Service
public class SubjectService {

	@Autowired
	SubjectRepository subjectRepository;
	
	public List<Subject> getAllStudents(){
		return subjectRepository.findAll();
	}
}
