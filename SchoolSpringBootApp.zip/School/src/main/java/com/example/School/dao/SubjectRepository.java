package com.example.School.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.School.model.Subject;

public interface SubjectRepository extends JpaRepository<Subject, Integer>{
	
}
