package com.example.School.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Student {

	@Id
	private int id;
	private String name;
	
	@ManyToMany
	private List<Subject> subjects = new ArrayList<>();
	 
	public Student() {
		
	}
	public Student(String name, List<Subject> subjects) {
		super();
		this.name = name;
		this.subjects = subjects;
	}
	
	
}
