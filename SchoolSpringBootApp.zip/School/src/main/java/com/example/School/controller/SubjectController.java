package com.example.School.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.School.model.Subject;
import com.example.School.service.SubjectService;

@RestController
public class SubjectController {

	@Autowired
	SubjectService subjectService;
	
	@GetMapping("/subjects")
	public List<Subject> getAllStudents(){
		return subjectService.getAllStudents(); 
	}
}
