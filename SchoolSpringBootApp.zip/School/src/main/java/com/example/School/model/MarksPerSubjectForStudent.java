package com.example.School.model;

public class MarksPerSubjectForStudent {

	private int id;
	private Subject subject;
	private Student student;
	private int marks;
	
	
}
