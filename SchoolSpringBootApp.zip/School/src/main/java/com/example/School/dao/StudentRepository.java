package com.example.School.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.School.model.Student;

public interface StudentRepository extends JpaRepository<Student, Integer>{
	
}
