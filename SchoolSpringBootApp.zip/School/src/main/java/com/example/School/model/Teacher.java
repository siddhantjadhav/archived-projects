package com.example.School.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Teacher {

	@Id
	private int id;
	private String name;
	
	@OneToOne
	private Subject subject;
	
	
}
