Any DB

Any auth engine

Student, subject and teacher entity

View 1 – Read only all entities

View 2 – Update subject marks

Controller, model, service, DAO

 